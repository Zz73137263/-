#ifndef __SERVO_H
#define __SERVO_H

void TIM5_PWM_Init(void);

void Servo_SetAngle1(uint16_t angle);

void Servo_SetAngle2(uint16_t angle);

#endif
