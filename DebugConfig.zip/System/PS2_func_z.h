#ifndef __PS2_func_z_h
#define __PS2_func_z_h

#include "stm32f10x.h"                  // Device header
#include "PS2_typ_z.h"


void PS2_Init(void);
PS2_DataTypeDef* PS2_ReadData(void);


#endif
