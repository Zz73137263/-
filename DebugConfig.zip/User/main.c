#include "stm32f10x.h"                  // Device header
#include "control.h"



int main(void)
{
	ALL_Init();
	while (1)
	{
		
	}
}

