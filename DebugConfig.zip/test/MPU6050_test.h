#ifndef __MPU6050_TEST_H
#define __MPU6050_TEST_H

#include "stm32f10x.h"

void MPU6050_test(void);

#endif
